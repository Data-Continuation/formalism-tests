# iosnoperiod

This directory mirrors leading-dot canonical paths for iOS-safe upload and extraction.
