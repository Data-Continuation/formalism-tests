# core-lite packet payload

This payload is a proposed governed transition, not installation authority.
