#!/usr/bin/env python3
from __future__ import annotations

import json
import shutil
from datetime import datetime, timezone
from pathlib import Path


TARGETS = [
    Path(".tmp/stegverse-001-remote-core-lite"),
]

REPORT = Path("reports/current/stegverse-001-remote-core-lite/runtime_cleanup_report.json")


def main() -> int:
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    removed = []
    absent = []

    for target in TARGETS:
        if target.exists():
            if target.is_dir():
                shutil.rmtree(target)
            else:
                target.unlink()
            removed.append(target.as_posix())
        else:
            absent.append(target.as_posix())

    report = {
        "schema": "stegverse_001_runtime_cleanup_report.v1",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "success": True,
        "removed": removed,
        "absent": absent,
        "note": "Runtime clone output should not be committed. Operator v2 uses system temp space by default.",
    }
    REPORT.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
